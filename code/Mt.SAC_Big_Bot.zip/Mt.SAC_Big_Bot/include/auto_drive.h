#ifndef AUTO_DRIVE
#define AUTO_DRIVE

#include "vex.h"
#include "robot_config.h"
#include "pid_control.h"
#include "odometry.h"
#include "ball_handler.h"
#include <cmath>

using namespace vex;
enum IntakeTurnOn {COLOR_SORT_ON, INTAKE, NOT_INTAKE}; 

class AutoDrive {
private:
    static double clamp(double x, double lo, double hi) {
        if (x > hi) return hi;
        if (x < lo) return lo;
        return x;
    }   

    static double slew(double target, double prev, double step_per_loop) {
        if (target > prev + step_per_loop) return prev += step_per_loop;
        else if (target < prev + step_per_loop) return prev -= step_per_loop; 
        return target; 
    }

    static bool stopTimeOut() {
        return rotVert.velocity(dps) == 0; 
    }

    static bool stopTimeOutTurn() {
        return inertial_sen.gyroRate(zaxis, dps) == 0.1; 
    }

public:
    double goStraight(double target = 0, double percent_pct = 30) {
        LeftGroup.setVelocity(percent_pct, percent);
        RightGroup.setVelocity(percent_pct, percent);

        double start = rotVert.position(degrees);
        double target_position = start - target;

        while (rotVert.position(degrees) - target_position < 0) {
            LeftGroup.spin(vex::forward);
            RightGroup.spin(vex::reverse);
            wait(10, msec);
        }

        LeftGroup.stop(brake);
        RightGroup.stop(brake);
        return target_position;
    }

    double goBackward(double targetDeg = 0, double speedPct = 10) {
        speedPct = fabs(speedPct);
        targetDeg = fabs(targetDeg);

        LeftGroup.setVelocity(speedPct, percent);
        RightGroup.setVelocity(speedPct, percent);

        double start = rotVert.position(degrees);
        double target_position = start - targetDeg;

        while (rotVert.position(degrees) > target_position) {
            LeftGroup.spin(vex::reverse);
            RightGroup.spin(vex::forward);
            wait(10, msec);
        }

        LeftGroup.stop(brake);
        RightGroup.stop(brake);
        return start;
    }

    double turnRight(double deg = 90, int drive_pct = 5) {
        double start = inertial_sen.rotation(degrees);
        double goal  = start + deg;

        RightGroup.setVelocity(drive_pct, percent);
        LeftGroup.setVelocity(drive_pct, percent);

        while (inertial_sen.rotation(degrees) < goal) {
            LeftGroup.spin(vex::forward);
            RightGroup.spin(vex::forward);
            wait(10, msec);
        }

        LeftGroup.stop(vex::brake);
        RightGroup.stop(vex::brake);
        return start;
    }

    double turnLeft(double deg = 90, int drive_pct = 5) {
        double start = inertial_sen.rotation(degrees);
        double goal  = start - deg;   

        RightGroup.setVelocity(drive_pct, percent);
        LeftGroup.setVelocity(drive_pct, percent);

        while (inertial_sen.rotation(degrees) > goal) {
            RightGroup.spin(vex::reverse);
            LeftGroup.spin(vex::reverse);
            wait(10, msec);
        }

        LeftGroup.stop(vex::brake);
        RightGroup.stop(vex::brake);
        return start;
    }
    
    static void driveToEncoderPD(double targetPosDeg, Odometry& odom, 
                        double v,    
                        double kP = 0.33, double kD = 0.08,
                        double maxPct = 30,
                        double settleErrDeg = 2.0,
                        int timeoutMs = 2500, IntakeTurnOn intake = IntakeTurnOn::INTAKE) {
        timer t; t.reset();

        PD_Control pd(kP, kD, targetPosDeg); 

        // add heading_hold
        double target_heading = inertial_sen.heading(); 
        PD_Control pd_heading_hold(0.05,30, target_heading);

        while (t.time(msec) < timeoutMs) {
            if (t.time(msec) >= 500 && stopTimeOut()) break; 
            double nowSec = t.time(msec) / 1000.0;   
            double curDeg = rotVert.position(degrees);
            double errDeg = targetPosDeg - curDeg;

            if (fabs(errDeg) <= settleErrDeg) break;

            double out = pd.compute(curDeg, nowSec, -maxPct, maxPct); 
            double heading_hold_speed = pd_heading_hold.compute(inertial_sen.heading(), nowSec, -0, 0);                                                                                                                                                                                                                                                                            


            double leftSide = 0, rightSide = 0; 

            leftSide = out + heading_hold_speed;
            rightSide = out - heading_hold_speed; 



            if (intake == IntakeTurnOn::INTAKE) {
                intakeBall(); 
            } else if (intake == IntakeTurnOn::COLOR_SORT_ON) {
                scoringMidGoal(); 
            } else if (intake == IntakeTurnOn::NOT_INTAKE) {
                stop_mechanism_motors(); 
            }

            LeftGroup.spin(vex::reverse,  leftSide, vex::percent);
            RightGroup.spin(vex::reverse, rightSide, vex::percent);

            odom.update();
            wait(10, msec);
        }

        LeftGroup.stop(brakeType::hold);
        RightGroup.stop(brakeType::hold);
    }


    static void goStraightPID(double deltaDeg, Odometry& odom, double v, 
                       double kP = 0.33,  double kD = 0.0,
                       double maxPct = 20,
                       double settleErrDeg = 30.0,
                       int timeoutMs = 3500, IntakeTurnOn intake = IntakeTurnOn::INTAKE) {
        double start = rotVert.position(degrees);
        double target = start - deltaDeg; 
        driveToEncoderPD(target, odom, v, kP, kD, maxPct, settleErrDeg, timeoutMs, intake);
    }

    static void goBackwardPID(double deltaDeg, Odometry& odom, double v, 
                       double kP = 0.33, double kD = 0.08,
                       double maxPct = 20,
                       double settleErrDeg = 30.0,
                       int timeoutMs = 5000, IntakeTurnOn intake = IntakeTurnOn::INTAKE) {
        double start = rotVert.position(degrees);
        double target = start - deltaDeg; 
        driveToEncoderPD(target, odom, v, kP, kD, maxPct, settleErrDeg, timeoutMs, intake);
    }

    static double wrapDeg(double deg) {
        while (deg > 180.0) deg -= 360.0;
        while (deg < -180.0) deg += 360.0;
        return deg;
    }

    static void turnToHeadingPD(double goalDeg, Odometry& odom,
                        double kP = 0.33, double kD = 0.08,
                        double maxPct = 20,
                        double settleErrDeg = 0.05,     
                        int timeoutMs = 2000,
                        double slewStepPct = 0.5) {
        timer t; t.reset();

        PD_Control pd(kP, kD, goalDeg);

        while (t.time(msec) < timeoutMs) {
            // if (t.time(msec) >= 200 && stopTimeOutTurn()) break; 
            double now = t.time(msec);
            double cur = inertial_sen.rotation(degrees);
            double err = goalDeg - cur;

            if (fabs(err) <= settleErrDeg) break;

            double out = pd.compute(cur, now);
            out = clamp(out, -maxPct, maxPct);


            LeftGroup.spin(vex::forward, out, percent);
            RightGroup.spin(vex::reverse, out, percent);

        }
        LeftGroup.stop(brake);
        RightGroup.stop(brake);

    }  
 
};

#endif