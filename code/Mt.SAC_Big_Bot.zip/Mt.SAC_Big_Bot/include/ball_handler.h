#ifndef OUTTAKE 
#define OUTTAKE 

#include "robot_config.h"
#include "color_sort.h"
#include "vex.h"
#include <string>

using namespace vex; 
using namespace std; 
static bool inBlueRange(double hue) {
    return (hue >= 200 && hue <= 230);
}

static bool inRedRange(double hue) {
    return (hue >= 0 && hue <= 10 || hue >= 350 && hue < 360);
}

static TEAM teamFromHue(double hue) {
    if (inBlueRange(hue)) return TEAM::BLUE;
    if (inRedRange(hue))  return TEAM::RED;
    return TEAM::NONE;
}

void scoringLowGoal() {
    // outtake_roller_top.setVelocity(100, percent);
    // outtake_roller_top.spin(vex::forward);


    // roller_intake_top.setVelocity(100, percent);
    // roller_intake_top.spin(vex::forward);

    // roller_intake_bot.setVelocity(100, percent);
    // roller_intake_bot.spin(vex::forward);

    // roller_tongue.setVelocity(100, percent);
    // roller_tongue.spin(vex::forward);
}

void scoringLowGoalChecked() {
    outtake_roller_top.setVelocity(100, percent);
    outtake_roller_top.spin(vex::forward);

    outtake_roller_bot.setVelocity(100, percent);
    outtake_roller_bot.spin(vex::reverse);

    roller_intake_top.setVelocity(100, percent);
    roller_intake_top.spin(vex::forward);

    roller_intake_bot.setVelocity(100, percent);
    roller_intake_bot.spin(vex::forward);

    roller_tongue.setVelocity(100, percent);
    roller_tongue.spin(vex::forward);

    roller_intake_bot_right.setVelocity(100, percent); 
    roller_intake_bot_right.spin(vex::forward); 
}

void outtakeBall() {
    inspection_optical_sensor_1.setLight(ledState::on);
    inspection_optical_sensor_1.setLightPower(50, percent);

    if (inspection_optical_sensor_1.isNearObject()) {
        double hue = inspection_optical_sensor_1.hue();

        Controller1.Screen.setCursor(1, 1);
        Controller1.Screen.print("Hue: %.1f   ", hue);
    } else {
        Controller1.Screen.setCursor(1, 1);
        Controller1.Screen.print("Hue: NONE  ");
    }

    // colorSort().rejectBalls();

    // roller_intake_bot.stop(brakeType::hold);

    colorSort().rejectBalls(); 

    roller_intake_top.setVelocity(100, percent);
    roller_intake_top.spin(vex::reverse);

    roller_intake_bot.setVelocity(100, percent);
    roller_intake_bot.spin(vex::reverse);

    outtake_roller_bot.setVelocity(100, percent);
    outtake_roller_bot.spin(vex::reverse);

    roller_tongue.setVelocity(100, percent);
    roller_tongue.spin(vex::reverse);

    roller_intake_bot_right.setVelocity(100, percent); 
    roller_intake_bot_right.spin(vex::reverse); 

    outtake_roller_top.setVelocity(100, percent);
    outtake_roller_top.spin(vex::reverse);

    // topIntakeMotor.setVelocity(100, percent);
    // topIntakeMotor.spin(vex::forward);
}

void intakeBall() {
    inspection_optical_sensor_1.setLight(ledState::on);
    inspection_optical_sensor_1.setLightPower(50, percent);

    if (inspection_optical_sensor_1.isNearObject()) {
        double hue = inspection_optical_sensor_1.hue();

        Controller1.Screen.setCursor(1, 1);
        Controller1.Screen.print("Hue: %.1f   ", hue);
    } else {
        Controller1.Screen.setCursor(1, 1);
        Controller1.Screen.print("Hue: NONE  ");
    }

    colorSort().rejectBalls();

    // roller_intake_bot.stop(brakeType::hold);

    outtake_roller_bot.stop(brakeType::hold);
    outtake_roller_top.stop(brakeType::hold);

    roller_intake_top.setVelocity(100, percent);
    roller_intake_top.spin(vex::reverse);

    roller_intake_bot.setVelocity(100, percent);
    roller_intake_bot.spin(vex::reverse);

    roller_intake_bot_right.setVelocity(100, percent); 
    roller_intake_bot_right.spin(vex::reverse); 

    roller_tongue.setVelocity(100, percent);
    roller_tongue.spin(vex::reverse);

    // outtake_roller_top.setVelocity(20, percent);
    // outtake_roller_top.spin(vex::forward);
    // outtake_roller_bot.setVelocity(100, percent);
    // outtake_roller_bot.spin(vex::reverse);

    // outtake_roller_top.setVelocity(100, percent);
    // outtake_roller_top.spin(vex::forward);

    // topIntakeMotor.setVelocity(100, percent);
    // topIntakeMotor.spin(vex::forward);
}


void scoringMidGoal() {
    // colorSort().rejectBalls();
    roller_intake_top.setVelocity(100, percent);
    roller_intake_top.spin(vex::reverse);

    roller_intake_bot.setVelocity(100, percent);
    roller_intake_bot.spin(vex::reverse);

    roller_intake_bot_right.setVelocity(100, percent); 
    roller_intake_bot_right.spin(vex::reverse); 

    outtake_roller_bot.setVelocity(100, percent);
    outtake_roller_bot.spin(vex::forward);

    roller_tongue.setVelocity(100, percent);
    roller_tongue.spin(vex::reverse);

    outtake_roller_top.setVelocity(100, percent);
    outtake_roller_top.spin(vex::reverse);
}

void toggle_intake() {
    activate_intake = !activate_intake; 
    if (activate_intake){
        Brain.Screen.clearScreen();
        Controller1.Screen.setCursor(1, 1);
        Controller1.Screen.print("MODE: INTAKE       ");
    }

    activate_two_front_wheels = true;
    if (activate_outtake_low_goal) {
        activate_outtake_low_goal = !activate_outtake_low_goal;
        prevOuttakeButton_lg = !prevOuttakeButton_lg; 
    }

    if (activate_outtake_top_goal) {
        activate_outtake_top_goal = !activate_outtake_top_goal; 
        prevOuttakeButton_tg = !prevOuttakeButton_tg;
    }

    if (activate_outtake_mid_goal) {
        activate_outtake_mid_goal = !activate_outtake_mid_goal; 
        prevOuttakeButton_mg = !prevOuttakeButton_mg;
    }

    if (activate_tongue) {
        activate_tongue =false; 
        prevTongueBtn = !prevTongueBtn; 
    }
}

void toggle_pneumatics() {
    activate_pneumatics = !activate_pneumatics; 
}

void toggle_tongue() {
    activate_tongue = !activate_tongue; 
    if (activate_intake) {
        activate_intake = !activate_intake; 
        prevIntakeButton = !prevIntakeButton;
    }

    if (activate_outtake_low_goal) {
        activate_outtake_low_goal = !activate_outtake_low_goal;
        prevOuttakeButton_lg = !prevOuttakeButton_lg; 
    }

    if (activate_outtake_top_goal) {
        activate_outtake_top_goal = !activate_outtake_top_goal; 
        prevOuttakeButton_tg = !prevOuttakeButton_tg;
    }

    if (activate_outtake_mid_goal) {
        activate_outtake_mid_goal = !activate_outtake_mid_goal; 
        prevOuttakeButton_mg = !prevOuttakeButton_mg;
    }
}

void toggle_outtake_lg() {
    activate_outtake_low_goal = !activate_outtake_low_goal;
    if (activate_outtake_low_goal) {
        Brain.Screen.clearScreen();
        Controller1.Screen.setCursor(1, 1);
        Controller1.Screen.print("MODE: LOW          ");
    }

    if (activate_intake) {
        activate_intake = !activate_intake; 
        prevIntakeButton = !prevIntakeButton;
    }
    if (!activate_two_front_wheels) activate_two_front_wheels = true;

    if (activate_outtake_top_goal) {
        activate_outtake_top_goal = !activate_outtake_top_goal; 
        prevOuttakeButton_tg = !prevOuttakeButton_tg;
    }
    if (activate_outtake_mid_goal) {
        activate_outtake_mid_goal = !activate_outtake_mid_goal; 
        prevOuttakeButton_mg = !prevOuttakeButton_mg;
    }

    if (activate_tongue) {
        activate_tongue =false; 
        prevTongueBtn = !prevTongueBtn; 
    }
}

void toggle_outtake_tg() {
    activate_outtake_top_goal = !activate_outtake_top_goal; 
    if (activate_outtake_top_goal) {
        Brain.Screen.clearScreen();
        Controller1.Screen.setCursor(1, 1);
        Controller1.Screen.print("MODE: TOP          ");
    }

    if (activate_intake) {
        activate_intake = !activate_intake; 
        prevIntakeButton = !prevIntakeButton;
    }
    if (activate_two_front_wheels) {
        activate_two_front_wheels = !activate_two_front_wheels; 
    }
    if (activate_outtake_low_goal) {
        activate_outtake_low_goal = !activate_outtake_low_goal;
        prevOuttakeButton_lg = !prevOuttakeButton_lg; 
    }
    if (activate_outtake_mid_goal) {
        activate_outtake_mid_goal = !activate_outtake_mid_goal; 
        prevOuttakeButton_mg = !prevOuttakeButton_mg;
    }

    if (activate_tongue) {
        activate_tongue =false; 
        prevTongueBtn = !prevTongueBtn; 
    }
}

void toggle_outtake_mg() {
    activate_outtake_mid_goal = !activate_outtake_mid_goal; 
    if (activate_outtake_mid_goal) {
        Brain.Screen.clearScreen();
        Controller1.Screen.setCursor(1, 1);
        Controller1.Screen.print("MODE: MID          ");
    }

    if (activate_intake) {
        activate_intake = !activate_intake; 
        prevIntakeButton = !prevIntakeButton;
    }
    if (activate_two_front_wheels) {
        activate_two_front_wheels = !activate_two_front_wheels; 
    }
    if (activate_outtake_low_goal) {
        activate_outtake_low_goal = !activate_outtake_low_goal;
        prevOuttakeButton_lg = !prevOuttakeButton_lg; 
    }
    if (activate_outtake_top_goal) {
        activate_outtake_top_goal = !activate_outtake_top_goal; 
        prevOuttakeButton_tg = !prevOuttakeButton_tg;
    }

    if (activate_tongue) {
        activate_tongue = true; 
        prevTongueBtn = !prevTongueBtn; 
    }

}

// void toggle_descore() {
//     activate_descore_sticks = !activate_descore_sticks; 
// }

void activatePneumatics() {
    pneu_tongue.set(activate_tongue);
    // pneu_top.set(!activate_outtake_top_goal);
    // pneu_descore.set(activate_descore_sticks);
}

void handleButton() {
    bool intakeButton = Controller1.ButtonB.pressing(); 
    bool outtakeButton_lg = Controller1.ButtonA.pressing(); 
    bool outtakeButton_tg = Controller1.ButtonX.pressing(); 
    bool outtakeButton_mg = Controller1.ButtonY.pressing(); 
    bool pneumaticButton = Controller1.ButtonUp.pressing(); 
    bool descoreButton = Controller1.ButtonL1.pressing(); 
    bool tongueButton = Controller1.ButtonR1.pressing(); 

    if (intakeButton && !prevIntakeButton) toggle_intake(); 
    if (outtakeButton_lg && !prevOuttakeButton_lg) toggle_outtake_lg(); 
    if (outtakeButton_tg && !prevOuttakeButton_tg) toggle_outtake_tg();
    if (outtakeButton_mg && !prevOuttakeButton_mg) toggle_outtake_mg(); 
    if (pneumaticButton && !prevPneumaticButton) toggle_pneumatics(); 
    // if (descoreButton && !prevDescoreButton) toggle_descore(); 
    if (tongueButton && !prevTongueBtn) toggle_tongue(); 

    if (descoreButton) {
        pneu_descore.set(false);
        Controller1.rumble("-");
    } else {
        pneu_descore.set(true);
    }

    prevIntakeButton = intakeButton; 
    prevOuttakeButton_lg = outtakeButton_lg; 
    prevOuttakeButton_tg = outtakeButton_tg;
    prevOuttakeButton_mg = outtakeButton_mg;
    prevPneumaticButton = pneumaticButton;
    prevTongueBtn = tongueButton;
    // prevDescoreButton = descoreButton; 
}

int outakeTask() {
    while (true) {
        handleButton(); 
        activatePneumatics(); 

        // ColorSort().setLedState(); 
        // pneu_top.set(activate_outtake_top_goal);

        // if (!activate_two_front_wheels) {
        //     frontWheelMotor1.stop(vex::coast);
        //     frontWheelMotor2.stop(vex::coast);
        // }

        vex::task::sleep(10);
    }

    return 0; 
}

#endif 
