#ifndef COLOR_SORT 
#define COLOR_SORT

#include "robot_config.h"
#include "ball_handler.h"
#include "vex.h"
#include <deque>

using namespace std;
using namespace vex;

enum class TEAM { BLUE, RED, NONE };

inline constexpr TEAM my_team = TEAM::BLUE;
inline constexpr TEAM my_opponent = TEAM::RED;

class ColorSort {
private:
    static bool inBlueRange(double hue) {
        return (hue >= 215 && hue <= 240);
    }

    static bool inRedRange(double hue) {
        return (hue >= 330 && hue <= 359);
    }

    static TEAM teamFromHue(double hue) {
        if (inBlueRange(hue)) return TEAM::BLUE;
        if (inRedRange(hue))  return TEAM::RED;
        return TEAM::NONE;
    }

    static constexpr int maximum_ball_intake = 6;
    
    inline static bool last_seen_from_bottom_distance_sensor = false;
    inline static bool last_seen_from_top_distance_sensor = false;

    static void rejectToFront() {
        outtake_roller_bot.stop(brakeType::hold);

        roller_intake_top.setVelocity(100, percent);
        roller_intake_top.spin(vex::forward);

        roller_intake_bot.setVelocity(80, percent);
        roller_intake_bot.spin(vex::forward);

        roller_tongue.setVelocity(100, percent);
        roller_tongue.spin(vex::forward);
    }

    static void timeRejectToFront(int ms = 300) {
        timer t; t.reset();

        while (t.time(msec) < ms) {
            rejectToFront(); 
            wait(10, msec);
        }
        stop_mechanism_motors(); 
    }

    static TEAM stableTeamRead(int samples = 1, int sample_ms = 10) {
        int blue = 0, red = 0, none = 0; 

        for (int i = 0; i < samples; i++){
            bool n1 = inspection_optical_sensor_1.isNearObject(); 
            bool n2 = inspection_optical_sensor_2.isNearObject(); 

            double hue = -1; 
            if (n1 && !n2) hue = inspection_optical_sensor_1.hue(); 
            else if (!n1 && n2) hue = inspection_optical_sensor_2.hue(); 
            else if (n1 && n2) hue = (inspection_optical_sensor_1.hue() + inspection_optical_sensor_2.hue()) / 2; 
            else {
                none++; 
                wait(sample_ms, msec);
                continue;
            }

            TEAM t = teamFromHue(hue);
            if (t == TEAM::BLUE) blue += 1; 
            else if (t ==TEAM::RED) red += 1; 
            else none += 1; 
            
            wait(sample_ms, msec);
        }

        int best = max(blue, red);
        if (best < (samples * 2) / 3) return TEAM::NONE; 

        return (blue > red) ? TEAM::BLUE : TEAM::RED;
    } 

public:
    ColorSort() = default; 

    static void setLedState() {
        inspection_optical_sensor_1.setLight(ledState::on);
        inspection_optical_sensor_1.setLightPower(50, percent);
    }

    static void rejectBalls() {
        setLedState();

        TEAM detected = TEAM::NONE; 
        if (inspection_optical_sensor_1.isNearObject() || inspection_optical_sensor_2.isNearObject()) {
            TEAM detected = stableTeamRead(2, 10);

            if (detected != my_team && detected != TEAM::NONE) {
                timeRejectToFront();
            } else {
                outtake_roller_bot.stop(brakeType::hold);
                outtake_roller_top.stop(brakeType::coast);

                roller_intake_top.setVelocity(100, percent);
                roller_intake_top.spin(vex::reverse);

                roller_intake_bot.setVelocity(100, percent);
                roller_intake_bot.spin(vex::reverse);

                roller_tongue.setVelocity(100, percent);
                roller_tongue.spin(vex::reverse);
            }
        } else {
            outtake_roller_bot.stop(brakeType::hold);
            outtake_roller_top.stop(brakeType::coast);

            roller_intake_top.setVelocity(100, percent);
            roller_intake_top.spin(vex::reverse);

            roller_intake_bot.setVelocity(100, percent);
            roller_intake_bot.spin(vex::reverse);

            roller_tongue.setVelocity(100, percent);
            roller_tongue.spin(vex::reverse);
        }
    }
};


static ColorSort& colorSort() {
    static ColorSort instance;
    return instance;
}

#endif
