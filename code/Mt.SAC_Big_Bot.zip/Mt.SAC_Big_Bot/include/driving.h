#ifndef DRIVING
#define DRIVING 

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>
#include <list> 
#include <cmath>
#include <iostream>

#include "vex.h"
#include "robot_config.h"
#include "ball_handler.h"
#include "pid_control.h"

using namespace vex; 
using namespace std;

void setBrakeForIndividualMotors(const brakeType& mode) {
    LeftMotor1.setBrake(mode);
    LeftMotor2.setBrake(mode);
    LeftMotor3.setBrake(mode);

    RightMotor1.setBrake(mode);
    RightMotor2.setBrake(mode);
    RightMotor3.setBrake(mode);
}


int max_motor_spd = 90;    
double cubic_coeff = 0.0001;  
const double kTurnScaleFast = 0.85;

double cubicScaling(double input) {
    return cubic_coeff * (input * input * input);  
}

int arcadeDrivingTaskCubic() {
    setBrakeForIndividualMotors(brakeType::coast);  

    while (true) {
        double forwardSpeed = -Controller1.Axis3.position(); 
        double turnSpeed = -Controller1.Axis1.position();  

        if (fabs(forwardSpeed) < 5) forwardSpeed = 0;
        if (fabs(turnSpeed) < 5) turnSpeed = 0;

        forwardSpeed = cubicScaling(forwardSpeed);
        turnSpeed = kTurnScaleFast * cubicScaling(turnSpeed);

        double left = (forwardSpeed - turnSpeed); 
        double right = (forwardSpeed + turnSpeed);

        left = std::max(-(double)max_motor_spd, std::min((double)max_motor_spd, left));
        right = std::max(-(double)max_motor_spd, std::min((double)max_motor_spd, right));

        LeftGroup.spin(vex::forward, left, vex::percent);
        RightGroup.spin(vex::forward, right, vex::percent);

        vex::task::sleep(10);  
    }

    return 0;
}

int shared_intake_lg_tasks() {
    while (true) {
        if (activate_intake || activate_tongue) {
            intakeBall(); 
        } else if (activate_outtake_top_goal) {
            outtakeBall(); 
        } else if (activate_outtake_low_goal) {
            scoringLowGoalChecked();
        } else if (activate_outtake_mid_goal) {
            scoringMidGoal(); 
        } else stop_mechanism_motors(); 
        
        vex::task::sleep(10);
    }
    return 0; 
}

void driverControl() {
    vex::task outake(outakeTask);
    vex::task shared_task(shared_intake_lg_tasks);
    vex::task driveTask(arcadeDrivingTaskCubic);
    
    while (true) {
        vex::task::sleep(10);
    }

}
 
#endif 




