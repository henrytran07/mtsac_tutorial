#ifndef PD_CONTROL
#define PD_CONTROL

#include "vex.h"
#include <cmath>

class PD_Control {
private:
    double kP;
    double kD;
    double target;

    double prevError = 0.0;
    double prevTimeSec = 0.0;
    bool first = true;

    static double clamp(double x, double lo, double hi) {
        if (x < lo) return lo;
        if (x > hi) return hi;
        return x;
  }

public:
    PD_Control(double kp, double kd, double desired)
        : kP(kp), kD(kd), target(desired) {}

    void setTarget(double desired) { target = desired; }

    double compute(double current, double timeSec,
                    double outMin = -100.0, double outMax = 100.0) {

        double error = target - current;

        double dt = 0.0;
        double dErr = 0.0;

        if (!first) {
            dt = timeSec - prevTimeSec;
            if (dt > 0.0) dErr = (error - prevError) / dt;
        
        } else {
            first = false;
        }

        prevError = error;
        prevTimeSec = timeSec;

        double output = kP * error + kD * dErr;
        return clamp(output, outMin, outMax);
    }

    void reset(double currentTimeSec = 0.0) {
        prevError = 0.0;
        prevTimeSec = currentTimeSec;
        first = true;
    }
};

#endif
