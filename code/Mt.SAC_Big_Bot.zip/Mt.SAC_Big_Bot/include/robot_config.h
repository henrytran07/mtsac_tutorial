#ifndef ROBOT_CONFIG 
#define ROBOT_CONFIG 

#include "vex.h"

using namespace vex;


// empty ports: 6, 15, 16, 17, 21
brain Brain;

motor LeftMotor1 = motor(PORT1, ratio6_1, true);

motor LeftMotor2 = motor(PORT2, ratio6_1, true);
motor LeftMotor3 = motor(PORT3, ratio6_1, true);
motor LeftMotor4 = motor(PORT4, ratio6_1, true);

motor RightMotor1 = motor(PORT11, ratio6_1, false);

motor RightMotor2 = motor(PORT12, ratio6_1, false);
motor RightMotor3 = motor(PORT13, ratio6_1, false);
motor RightMotor4 = motor(PORT14, ratio6_1, false);

motor roller_intake_top = motor(PORT18, ratio18_1, true);
motor roller_intake_bot = motor(PORT17, ratio6_1, false);
motor roller_intake_bot_right = motor(PORT8, ratio6_1, true); 

motor roller_tongue = motor(PORT20, ratio6_1, false);

motor outtake_roller_bot = motor(PORT16, ratio6_1, true);
motor outtake_roller_top = motor(PORT15, ratio6_1, false);

rotation rotVert = rotation(PORT9, true);
rotation rotHor = rotation(PORT16, false);
inertial inertial_sen = inertial(PORT10);

optical inspection_optical_sensor_1 = optical(PORT16);
optical inspection_optical_sensor_2 = optical(PORT16);
optical parking_optical_sensor = optical(PORT20);

vex::vision::signature TOWER_SKILLS(1, 4561, 5273, 4917, -4033, -3665, -3849, 2.5, 0);

// practice field
// vex::vision::signature TOWER_SKILLS(1, 3459, 3933, 3696, -3537, -3189, -3363, 2.5, 0);

vex::vision::signature BLUE_BLOCK(2, -3305, -2699, -3002, 5311, 6409, 5860, 2.5, 0);
vex::vision::signature RED_BLOCK(2, 9301, 10979, 10140, -987, -293, -640, 2.5, 0);

vision vision_1(
    PORT6,
    45,
    TOWER_SKILLS
);

// // practice field
// vision vision_1(
//     PORT6,
//     50,
//     TOWER_SKILLS
// );

vision vision_2(PORT20, 70, BLUE_BLOCK, RED_BLOCK);

digital_out pneu_tongue = digital_out(Brain.ThreeWirePort.A);
digital_out pneu_descore = digital_out(Brain.ThreeWirePort.E);
digital_out pneu_top = digital_out(Brain.ThreeWirePort.D);

vex::distance parking_distance_sensor = vex::distance(PORT7);
controller Controller1 = controller(primary);
vex::motor_group LeftGroup(LeftMotor1, LeftMotor2, LeftMotor3, LeftMotor4);
vex::motor_group RightGroup(RightMotor1, RightMotor2, RightMotor3, RightMotor4);

// mechanism activation flags 
static bool activate_intake = false; 
static bool activate_two_front_wheels = false; 
static bool activate_chains = false; 
static bool activate_outtake_low_goal = false; 
static bool activate_outtake_top_goal = false; 
static bool activate_outtake_mid_goal = false; 
static bool activate_pneumatics = false; 
// static bool activate_descore_sticks = false; 
static bool activate_tongue = false; 


// prevButton flags 
static bool prevIntakeButton = false; 
static bool prevOuttakeButton_lg = false; 
static bool prevOuttakeButton_tg = false; 
bool prevOuttakeButton_mg = false;
static bool prevPneumaticButton = false; 
static bool prevOverrideSortingBtn = false;    
static bool prevDescoreButton = false; 
static double target_heading = 0;
static bool prevTongueBtn = false; 

void initializeRandomSeed(){
    int systemTime = Brain.Timer.systemHighResolution();
    double batteryCurrent = Brain.Battery.current();
    double batteryVoltage = Brain.Battery.voltage(voltageUnits::mV);

    int seed = int(batteryVoltage + batteryCurrent * 100) + systemTime;

    srand(seed);
}

static double wrapDeg(double deg){
    while (deg > 180) deg -= 360;
    while (deg < -180) deg += 360;
    return deg;
}

void preAuton() {
    initializeRandomSeed(); 
    inertial_sen.calibrate();
    while (inertial_sen.isCalibrating()) wait(10, msec);

    pneu_tongue.set(activate_tongue); //Set pneumatics to initial position
    pneu_descore.set(true);
    // Get initial heading from inertial
    target_heading = wrapDeg(inertial_sen.rotation(degrees));
}

void initOpticalSensor() {
    inspection_optical_sensor_1.integrationTime(5);
    inspection_optical_sensor_1.objectDetectThreshold(50);

    inspection_optical_sensor_2.integrationTime(5);
    inspection_optical_sensor_2.objectDetectThreshold(50);

    parking_optical_sensor.integrationTime(5);
    parking_optical_sensor.objectDetectThreshold(50);
}

void stop_mechanism_motors() {
    roller_intake_top.stop(vex::brakeType::coast); 
    roller_intake_bot.stop(vex::brakeType::coast); 
    roller_intake_bot_right.stop(vex::brakeType::coast); 

    outtake_roller_bot.stop(vex::brakeType::hold);
    roller_tongue.stop(vex::brakeType::coast);
    outtake_roller_top.stop(vex::brakeType::hold);
}
#endif 