#ifndef ROUTINE_CONFIG
#define ROUTINE_CONFIG

#include "auto_drive.h"
#include "vex.h"
#include "odometry.h"
#include "ball_handler.h"
#include "color_sort.h"

#include <vector>
#include <map>
#include <functional>
#include <tuple>

using namespace vex;
using namespace std;

static double err_x = 0; 
static double err_y = 0; 
static double err_headings = 0; 

class AutoDrive;

enum Side { LEFT, RIGHT };
enum Distance {LONG_DISTANCE, SHORT_DISTANCE};

enum RoutineID { R0, R1, R2, R3 };

struct Step {
    enum Type { STRAIGHT, BACKWARD, TURN_LEFT, TURN_RIGHT, TOP_GOAL, MIDDLE_GOAL,LOW_GOAL, STOP, BALL_LOADING, RESET, CLEAR_PARKING, TONGUE_PNEUMATICS, DESCORE, NO_BACKTRACKSCORING, FILTER_SORT, VISION_FIX, FIX_HEADING, HIGH_GOAL_FIX, PARKING, HEADING_TURN, DRIVE_MOTOR} type;
    double v1;
    double v2; 
    bool v3; 
    double v4;  
    IntakeTurnOn v5; 
    double v6; 
};

using RoutineStep = function<void(AutoDrive&, Odometry&)>;
using Routine     = vector<RoutineStep>;
using Key         = pair<RoutineID, Side>;

static const double wheel_c = M_PI * 0.0508;

static TEAM detectTeamFromHue(double hue) {
    if (hue >= 190 && hue <= 250)
        return TEAM::BLUE; 
    else if ((hue >= 300 && hue <= 359) || (hue >= 0 && hue <= 30))
        return TEAM::RED; 
    else 
        return TEAM::NONE;
}

static void printOdom(Odometry& odom) {
    double x = odom.getX();
    double y = odom.getY();
    double h = odom.get_headings();

    Controller1.Screen.clearScreen();
    Controller1.Screen.setCursor(1, 1);
    Controller1.Screen.print("x: %.2f", x);
    Controller1.Screen.setCursor(2, 1);
    Controller1.Screen.print("y: %.2f", y);
    Controller1.Screen.setCursor(3, 1);
    Controller1.Screen.print("heading: %.2f", h);
}

static double encoder_ticks(double meters){
    return (meters / wheel_c) * 360; 
}   


static double x_corrected(Odometry& odom) {
    return odom.getX() + err_x; 
}

static double y_corrected(Odometry& odom) {
    return odom.getY() + err_y; 
}

static double heading_corrected(Odometry& odom) {
    return wrapDeg(odom.get_headings() + err_headings); 
}


static void addStraight(Routine& actions, double distance, double v, IntakeTurnOn intake, double speed) {
    actions.push_back([distance, v, intake, speed](AutoDrive &d, Odometry& odom) {
        stop_mechanism_motors();

        odom.update();
        double x0 = x_corrected(odom);
        double y0 = y_corrected(odom);

        double ticks = encoder_ticks(distance);
        double kP, kD; 

        kP = 0.08; 
        kD = 0.001; 
        d.goStraightPID(-ticks, odom, v, kP, kD, speed, 8, v, intake);

        odom.update();
        double x1 = x_corrected(odom);
        double y1 = y_corrected(odom);

        double dx = x1 - x0;
        double dy = y1 - y0;

        double th = v * M_PI / 180.0;
        double ux = sin(th), uy = cos(th);
        double px = uy,      py = -ux;

        double forward_actual = dx * ux + dy * uy;
        double lateral_actual = dx * px + dy * py;

        double dist_expected = +distance;

        err_y += (dist_expected - forward_actual);
        err_x += (0.0 - lateral_actual);

        double imuH  = wrapDeg(inertial_sen.rotation(degrees));
        double odomH = wrapDeg(odom.get_headings());

        double hErr = wrapDeg(imuH - odomH);
        err_headings = wrapDeg(err_headings + hErr);


        inspection_optical_sensor_1.setLight(ledState::off);
        inspection_optical_sensor_2.setLight(ledState::off);
        printOdom(odom);
    });
}



static void addBackward(Routine& actions, double distance, double v,  IntakeTurnOn intake, double speed) {
    actions.push_back([distance, v, intake, speed](AutoDrive &d, Odometry& odom) {
        stop_mechanism_motors(); 
        odom.update();
        double x0 = x_corrected(odom);
        double y0 = y_corrected(odom);

        double ticks = encoder_ticks(distance); 
        double kP, kD; 

        kP = 0.08; 
        kD = 0.001; 
        d.goBackwardPID(ticks, odom, v, kP, kD, speed, 8, v, intake);

        odom.update();
        double x1 = x_corrected(odom);
        double y1 = y_corrected(odom);

        double dx = x1 - x0;
        double dy = y1 - y0;

        double th = v * M_PI / 180.0;
        double ux = sin(th), uy = cos(th);
        double px = uy,      py = -ux;

        double forward_actual = dx * ux + dy * uy;
        double lateral_actual = dx * px + dy * py;

        double dist_expected = -distance;

        err_y += (dist_expected - forward_actual);
        err_x += (0.0 - lateral_actual);

        double imuH  = wrapDeg(inertial_sen.rotation(degrees));
        double odomH = wrapDeg(odom.get_headings());

        double hErr = wrapDeg(imuH - odomH);
        err_headings = wrapDeg(err_headings + hErr);

        inspection_optical_sensor_1.setLight(ledState::off);
        inspection_optical_sensor_2.setLight(ledState::off);
        printOdom(odom);
    });
}


static void addTurnRight(Routine& actions, double angleDeg, Distance type = Distance::LONG_DISTANCE) {
    actions.push_back([angleDeg, type](AutoDrive &d, Odometry& odom) {

        target_heading = target_heading + angleDeg;   
        stop_mechanism_motors(); 
        double kP = 0, kD = 0; 
        if (type == Distance::LONG_DISTANCE)
            kP = 0.68, kD = 4.15;
        else if (type == Distance::SHORT_DISTANCE)
            kP = 0.35, kD = 16.15; 
        
        d.turnToHeadingPD(target_heading, odom, kP, kD, 30, 0.1, 1000, 0.4);

        odom.update();
        double imuH  = wrapDeg(inertial_sen.rotation(degrees));
        double odomH = wrapDeg(odom.get_headings());

        double hErr = wrapDeg(imuH - odomH);
        err_headings = wrapDeg(err_headings + hErr);

        printOdom(odom);
    });
}

static void driveByMotors(Routine& actions, double timeOut = 300) {
    actions.push_back([timeOut](AutoDrive &d, Odometry& odom) {
        timer t; t.reset(); 

        while (t.time(msec) < timeOut) {
            LeftGroup.setVelocity(30, percent); 
            RightGroup.setVelocity(30, percent);
            LeftGroup.spin(vex::reverse); 
            RightGroup.spin(vex::reverse); 
            wait(20, msec); 
        }

        LeftGroup.stop(brakeType::hold); 
        RightGroup.stop(brakeType::hold); 
    });
}

static void addTurnLeft(Routine& actions, double angleDeg, Distance type = Distance::LONG_DISTANCE) {
    actions.push_back([angleDeg, type](AutoDrive &d, Odometry& odom) {
        target_heading = target_heading - angleDeg; 
        stop_mechanism_motors(); 
        double kP = 0, kD = 0; 
        if (type == Distance::LONG_DISTANCE)
            kP = 0.65, kD = 4.15;
        else if (type == Distance::SHORT_DISTANCE)
            kP = 0.35, kD = 16.15; 
        
        d.turnToHeadingPD(target_heading, odom, kP, kD, 30, 0.1, 1000);

        odom.update();
        double imuH  = wrapDeg(inertial_sen.rotation(degrees));
        double odomH = wrapDeg(odom.get_headings());

        double hErr = wrapDeg(imuH - odomH);
        err_headings = wrapDeg(err_headings + hErr);

        printOdom(odom);
    });
}


double clamp(double value, double minVal, double maxVal) {
    if (value < minVal) return minVal;
    if (value > maxVal) return maxVal;
    return value;
}

static void visionFix(Routine& actions, int timeOutms = 3000, double projected_distance = 0.5, double width = 3.8, double backward_distance = 0.0, IntakeTurnOn intake = IntakeTurnOn::NOT_INTAKE, double kP = 0.18, double kD = 0.0) {
    actions.push_back([timeOutms, kP, kD, projected_distance, width, backward_distance, intake](AutoDrive &d, Odometry& odom) {
        timer t; t.reset();
        double targetPosDeg = rotVert.position(degrees) - encoder_ticks(backward_distance);
        PD_Control pd_backward(0.08, 0.001, targetPosDeg); 

        double target_heading = inertial_sen.heading(); 

        while (t.time(msec) < 2000) {
            double nowSec = t.time(msec) / 1000.0;   
            double curDeg = rotVert.position(degrees);
            double errDeg = targetPosDeg - curDeg;

            if (fabs(errDeg) <= 30) {
                break;
            }

            double out = pd_backward.compute(curDeg, nowSec, -50, 50);                                                                                                                                                                                                                                                                      

            double leftSide = 0, rightSide = 0; 
  
            leftSide = out; rightSide = out; 
            if (intake == IntakeTurnOn::INTAKE) {
                intakeBall(); 
            } else if (intake == IntakeTurnOn::COLOR_SORT_ON) {
                scoringMidGoal(); 
            } else if (intake == IntakeTurnOn::NOT_INTAKE) {
                stop_mechanism_motors(); 
            }

            LeftGroup.spin(vex::reverse,  leftSide, vex::percent);
            RightGroup.spin(vex::reverse, rightSide, vex::percent);

            odom.update();
            wait(10, msec);
        }

        bool intake_run = (backward_distance != 0); 

        const double offsetX    = 15.0;
        const double tolerance = 15.0;
        const double imageWidth = 316.0;

        const double knownObjectWidth  = width;
        const double hFOV_deg     = 64.6;

        const int cameraFocalLength = (imageWidth / 2.0) / tan((hFOV_deg / 2.0) * M_PI / 180.0);
        t.reset();

        int  noObjectCount = 0;
        
        vision_1.takeSnapshot(TOWER_SKILLS); 

        if (!vision_1.largestObject.exists) {
            return; 
        }
        vex::vision::object initial_captured_tower = vision_1.largestObject; 

        double errPx_init = initial_captured_tower.centerX - (imageWidth / 2 + offsetX);
        double estimatedDistance_init = (double)(knownObjectWidth * cameraFocalLength) / initial_captured_tower.width;
        double initial_distance = estimatedDistance_init / 39.3701;

        double initial_target = (initial_distance + projected_distance) / 2.0; 
        double target_pos = rotVert.position(degrees) - encoder_ticks(initial_distance);
        PD_Control pd(kP, kD, target_pos); 

        timer intake_run_time; intake_run_time.reset(); 

        stop_mechanism_motors(); 
        while (t.time(vex::msec) < timeOutms) {
            vision_1.takeSnapshot(TOWER_SKILLS);

            if (vision_1.largestObject.exists) {
                noObjectCount = 0;
                vex::vision::object tower = vision_1.largestObject;

                double errPx = tower.centerX - (imageWidth / 2 + offsetX);
                double estimatedDistance = (double)(knownObjectWidth * cameraFocalLength) / tower.width;
                double estimatedDistanceMeters = estimatedDistance / 39.3701;
                Controller1.Screen.print("D: %.2f", estimatedDistanceMeters);
                
                double ticks = encoder_ticks(estimatedDistanceMeters);
                double nowSec = t.time(msec) / 1000.0;   

                double out = pd.compute(rotVert.position(degrees), nowSec, -20, 20); 

                double turn_speed = kP * errPx;
                turn_speed = clamp(turn_speed, -20.0, 20.0);

                double drive_speed = (rotVert.velocity(dps) == 0 && t.time(msec) > 200) ? 0 : 10; 
                if (drive_speed == 0) break; 

                if (fabs(out) > fabs(drive_speed) && out != 0) drive_speed = fabs(out); 

                if (fabs(errPx) <= tolerance) {
                    turn_speed = 0; 
                } 

                double left  = drive_speed - turn_speed;
                double right = drive_speed + turn_speed;

                LeftGroup.spin(vex::forward,  left,  vex::percent);
                RightGroup.spin(vex::forward, right, vex::percent);

            } else {
                noObjectCount++;

                if (noObjectCount >= 5) {
                    Controller1.Screen.print("Target lost!");
                    break;
                }

                LeftGroup.spin(vex::forward, 20, vex::percent);
                RightGroup.spin(vex::forward, 20, vex::percent);
            }

            if (intake_run && intake_run_time.time(msec) < 500) { 
                if (intake == IntakeTurnOn::COLOR_SORT_ON) {
                    scoringMidGoal(); 
                } else if (intake == IntakeTurnOn::NOT_INTAKE) {
                    stop_mechanism_motors(); 
                }      
            }
            wait(20, msec); 
        }

        LeftGroup.stop(vex::hold);
        RightGroup.stop(vex::hold);
    });
}


static void addTopGoalNoBT(Routine& actions, int wait_ms) {
    actions.push_back([wait_ms](AutoDrive &d, Odometry& odom) {
        timer t; t.reset();
        while (t.time(msec) < wait_ms) {
            outtakeBall(); 
            wait(10, msec);
        }

        odom.update();
        printOdom(odom);

        stop_mechanism_motors();
        inspection_optical_sensor_1.setLight(ledState::off);
    });
}
static void addMiddleGoal(Routine& actions, double wait_time) {
    actions.push_back([wait_time](AutoDrive &d, Odometry& odom) {
        timer t; t.reset(); 
        while (t.time(msec) < wait_time) {
            roller_intake_top.setVelocity(100, percent);
            roller_intake_top.spin(vex::reverse);

            roller_intake_bot.setVelocity(100, percent);
            roller_intake_bot.spin(vex::reverse);

            roller_intake_bot_right.setVelocity(100, percent);
            roller_intake_bot_right.spin(vex::reverse);

            outtake_roller_bot.setVelocity(20, percent);
            outtake_roller_bot.spin(vex::forward);

            roller_tongue.setVelocity(100, percent);
            roller_tongue.spin(vex::reverse);

            outtake_roller_top.setVelocity(50, percent);
            outtake_roller_top.spin(vex::reverse);
            wait(10, msec);
        }
        odom.update();
        printOdom(odom);
    });
}

static void addLowGoal(Routine& actions, double wait_time) {
    actions.push_back([wait_time](AutoDrive &d, Odometry& odom) {
        timer t; t.reset(); 
        while (t.time(msec) < wait_time) {
            scoringLowGoalChecked();
            wait(10, msec);
        }
        odom.update();
        printOdom(odom);
    });
}

static void addBallLoading(Routine& actions, int timeOutms = 3000) {
    actions.push_back([timeOutms](AutoDrive &d, Odometry& odom) {
        timer t; t.reset(); 
        while (t.time(msec) < timeOutms) {
            intakeBall();
        }
    });
}

static void tongue_pneumatics(Routine& actions, bool pneumatics) {
    actions.push_back([pneumatics](AutoDrive &d, Odometry& odom) {
        pneu_tongue.set(pneumatics);
        pneu_descore.set(pneumatics);
    });
}

static void descore_pneumatics(Routine& actions, bool pneumatics) {
    actions.push_back([pneumatics](AutoDrive &d, Odometry& odom) {
        pneu_descore.set(pneumatics);
    });
}

static void resetOdom(Routine& actions) {
    actions.push_back([](AutoDrive &d, Odometry& odom) {
        err_x = 0; 
        err_y = 0; 
        err_headings = 0; 
        target_heading = inertial_sen.heading(); 
    });   
}


static void goParking(Routine& actions) {
    actions.push_back([](AutoDrive &d, Odometry& odom) {
        parking_optical_sensor.setLight(ledState::on);
        parking_optical_sensor.setLightPower(100, percent);
        wait(50, msec);
        double og_value = parking_optical_sensor.hue();
        double backward_value = og_value; 

        LeftGroup.setVelocity(40, percent);
        RightGroup.setVelocity(40, percent);
        LeftGroup.spin(vex::reverse);
        RightGroup.spin(vex::reverse);

        timer t; t.reset();
        while (t.time(msec) < 3000) {
            intakeBall();
            double en_value = parking_optical_sensor.hue();

            Controller1.Screen.clearLine();
            Controller1.Screen.setCursor(1, 1);
            Controller1.Screen.print("en:%.1f og:%.1f", en_value, og_value);

            if (detectTeamFromHue(en_value) == TEAM::BLUE || detectTeamFromHue(en_value) == TEAM::RED) {
                break;
            }

            wait(10, msec);
        }

        LeftGroup.stop(brakeType::hold);
        RightGroup.stop(brakeType::hold);

        LeftGroup.setVelocity(25, percent);
        RightGroup.setVelocity(25, percent);
        LeftGroup.spin(vex::forward);
        RightGroup.spin(vex::forward);

        t.reset();
        while (t.time(msec) < 2000) {
            intakeBall();
            double en_value = parking_optical_sensor.hue();

            Controller1.Screen.clearLine();
            Controller1.Screen.setCursor(1, 1);
            Controller1.Screen.print("en:%.1f bk:%.1f", en_value, backward_value);

            if (detectTeamFromHue(en_value) == TEAM::NONE) break;

            wait(10, msec);
        }

        LeftGroup.stop(brakeType::hold);
        RightGroup.stop(brakeType::hold);

        LeftGroup.setVelocity(25, percent);
        RightGroup.setVelocity(25, percent);
        LeftGroup.spin(vex::forward);
        RightGroup.spin(vex::forward);

        t.reset();
        while (t.time(msec) < 3000) {
            intakeBall();
            double en_value = parking_optical_sensor.hue();

            Controller1.Screen.clearLine();
            Controller1.Screen.setCursor(1, 1);
            Controller1.Screen.print("en:%.1f og:%.1f", en_value, og_value);

            if (detectTeamFromHue(en_value) == TEAM::BLUE || detectTeamFromHue(en_value) == TEAM::RED) {
                break;
            }

            wait(10, msec);
        }

        LeftGroup.stop(brakeType::hold);
        RightGroup.stop(brakeType::hold);

        parking_optical_sensor.setLight(ledState::off);
    });
}

static void escapingParking(Routine& actions) {
    actions.push_back([](AutoDrive &d, Odometry& odom, double c = 200) {
        double tolerance = 0;

        // skills 1050
        double target = 1050;

        double distance = parking_distance_sensor.objectDistance(mm);

        while(distance > target + tolerance) {

            if(distance <= 0 || distance > 2000) {
                distance = parking_distance_sensor.objectDistance(mm);
                continue;
            }

            Controller1.Screen.clearLine();
            Controller1.Screen.setCursor(1,1);
            Controller1.Screen.print("Dist: %.1f", distance);

            LeftGroup.setVelocity(50, percent); 
            RightGroup.setVelocity(50, percent); 

            LeftGroup.spin(vex::forward); 
            RightGroup.spin(vex::forward);
            distance = parking_distance_sensor.objectDistance(mm); 

        }

        Controller1.Screen.clearLine();
        Controller1.Screen.setCursor(1,1);
        Controller1.Screen.print("Dist: %.1f", distance);

        LeftGroup.stop(brakeType::hold);
        RightGroup.stop(brakeType::hold);
    });

}
double wrap180(double a) {
    while (a > 180.0) a -= 360.0;
    while (a <= -180.0) a += 360.0;
    return a;
}
double angleDiffDeg(double targetDeg, double currentDeg) {
    return wrap180(targetDeg - currentDeg);
}

void tankDrive(double leftPct, double rightPct) {
    LeftGroup.spin(fwd, clamp(leftPct, -20, 20), percent);
    RightGroup.spin(fwd, clamp(rightPct, -20, 20), percent);
}

static void fixHighGoal(Routine& actions, double desired_heading = -90, double timeOutMs = 2000){
    actions.push_back([desired_heading, timeOutMs](AutoDrive &d, Odometry& odom){
        timer t;
        t.reset();

        while (t.time(msec) < timeOutMs) {
            const double h = inertial_sen.heading(deg);
            const double hErr = angleDiffDeg(desired_heading, h);

            if (fabs(hErr) < 1.0) break;

            if (hErr > 0.0) {
                tankDrive(15, -10);
            } else {
                tankDrive(-10, 15);
            }

            wait(20, msec);
        }
        LeftGroup.stop(hold); 
        RightGroup.stop(hold); 
    }); 
}

static Routine buildRoutine(const vector<Step>& steps) {
    Routine actions;
    for (const auto &s : steps) {
        switch (s.type) {
            case Step::STRAIGHT:      addStraight(actions, s.v1, s.v2, s.v5, s.v4); break;
            case Step::BACKWARD:      addBackward(actions, s.v1, s.v2, s.v5, s.v4); break;
            case Step::TURN_LEFT:     addTurnLeft(actions, s.v1); break;
            case Step::TURN_RIGHT:    addTurnRight(actions, s.v1); break;
            case Step::MIDDLE_GOAL:      addMiddleGoal(actions, s.v1); break;
            case Step::LOW_GOAL:      addLowGoal(actions, s.v1); break;
            case Step::BALL_LOADING:  addBallLoading(actions, s.v1); break;
            case Step::RESET:          resetOdom(actions); break; 
            case Step::TONGUE_PNEUMATICS: tongue_pneumatics(actions, s.v3); 
            case Step::DESCORE: descore_pneumatics(actions, s.v3); 
            case Step::NO_BACKTRACKSCORING: addTopGoalNoBT(actions, s.v1); break; 
            case Step::VISION_FIX: visionFix(actions, s.v1, s.v2, s.v4, s.v6, s.v5); break; 
            case Step::PARKING: goParking(actions); break; 
            case Step::CLEAR_PARKING: escapingParking(actions); break; 
            case Step::HIGH_GOAL_FIX : fixHighGoal(actions, s.v1, s.v2); break; 
            case Step::DRIVE_MOTOR: driveByMotors(actions, s.v1); break; 
        }
    }
    return actions;
}


// skill 
static vector<Step> skills2 = {
    {Step::STRAIGHT, 1.03, 3000, 0 , 60, IntakeTurnOn::NOT_INTAKE},
    {Step::TURN_LEFT, 90}, 
    {Step::TONGUE_PNEUMATICS, 0, 0, true, IntakeTurnOn::INTAKE},
    {Step::STRAIGHT, 0.22, 1500, 0 , 40, IntakeTurnOn::INTAKE},
    {Step::BALL_LOADING, 850}, 
    {Step::BACKWARD, 0.24, 1500, 0, 20, IntakeTurnOn::INTAKE},
    {Step::TONGUE_PNEUMATICS, 0, 0, false, IntakeTurnOn::INTAKE},
    {Step::DESCORE, 0, 0, true},
    {Step::TURN_RIGHT, 95}, 
    {Step::STRAIGHT, 0.45, 1500, 0, 30, IntakeTurnOn::INTAKE},
    {Step::TURN_RIGHT, 80}, 
    // {Step::TURN_LEFT, 90},
    {Step::STRAIGHT, 2.03, 3000, 0, 70, IntakeTurnOn::INTAKE},
    {Step::TURN_LEFT, 88},
    {Step::BACKWARD, 0.33, 1500, 0, 20, IntakeTurnOn::INTAKE},
    // {Step::FIND_WALL},
    {Step::TURN_RIGHT, 93},
    {Step::VISION_FIX, 30000, 0.0, 0, 3.83, IntakeTurnOn::INTAKE, 0}, 
    {Step::HIGH_GOAL_FIX, 90, 500}, 
    {Step::NO_BACKTRACKSCORING, 1500}, 
    {Step::TONGUE_PNEUMATICS, 0, 0, true, IntakeTurnOn::INTAKE},
    {Step::STRAIGHT, 0.7, 3000, 0, 40, IntakeTurnOn::INTAKE}, 
    {Step::BALL_LOADING, 800}, 
    {Step::VISION_FIX, 30000, 0.7, 0, 3.83, IntakeTurnOn::INTAKE, 0.1}, 
        {Step::HIGH_GOAL_FIX, 90, 500}, 
    {Step::NO_BACKTRACKSCORING, 700}, 
    {Step::TONGUE_PNEUMATICS, 0, 0, false, IntakeTurnOn::INTAKE},
    {Step::STRAIGHT, 0.45, 3000, 0, 50, IntakeTurnOn::NOT_INTAKE}, 
    {Step::TURN_LEFT, 90}, 
    {Step::STRAIGHT, 0.40, 3000, 0, 20, IntakeTurnOn::INTAKE}, 
    {Step::BACKWARD, 0.04, 3000, 0, 100, IntakeTurnOn::INTAKE}, 
    // {Step::STRAIGHT, 0.04, 3000, true, 100},
    {Step::BACKWARD, 0.9, 3000, 0, 50, IntakeTurnOn::INTAKE}, 
    {Step::TURN_RIGHT, 90}, 
    {Step::STRAIGHT, 0.45, 3000, 0, 25, IntakeTurnOn::NOT_INTAKE}, 
    {Step::TURN_RIGHT, 75},
    {Step::STRAIGHT, 0.15, 3000, 0, 10, IntakeTurnOn::NOT_INTAKE}, 
    {Step::TONGUE_PNEUMATICS, 0, 0, true, IntakeTurnOn::INTAKE},
    {Step::PARKING}, 
    {Step::TONGUE_PNEUMATICS, 0, 0, false, IntakeTurnOn::INTAKE},
    {Step::DESCORE, 0, 0, true},
    {Step::DRIVE_MOTOR, 400}, 
    {Step::CLEAR_PARKING}, 
    {Step::TURN_RIGHT, 100}, 
    {Step::STRAIGHT, 2.2, 3000, 0, 70, IntakeTurnOn::INTAKE}, 
    {Step::TURN_RIGHT, 45}, 
    // {Step::VISION_FIX, 500}, 
    {Step::VISION_FIX, 30000, 0.3, 0, 7, IntakeTurnOn::NOT_INTAKE, 0}, 
    {Step::STRAIGHT, 0.05, 3000, 0, 100, IntakeTurnOn::NOT_INTAKE}, 
    {Step::MIDDLE_GOAL, 2000}, 
    {Step::STRAIGHT, 0.40, 3000, 0, 50, IntakeTurnOn::NOT_INTAKE}, 
    {Step::TURN_LEFT, 45},
    {Step::STRAIGHT, 1.05, 3000, 0, 50, IntakeTurnOn::NOT_INTAKE}, 
    // {Step::BACKWARD, 0.1, 3000, 0, 60, IntakeTurnOn::INTAKE}, 
    {Step::TURN_LEFT, 70}, 
    {Step::PARKING},
};

static vector<Step> skills = {
    {Step::STRAIGHT, 1.04, 3000, 0 , 60, IntakeTurnOn::NOT_INTAKE},
    {Step::TURN_LEFT, 90}, 
    {Step::TONGUE_PNEUMATICS, 0, 0, true, IntakeTurnOn::INTAKE},
    {Step::STRAIGHT, 0.32, 1500, 0 , 40, IntakeTurnOn::INTAKE},
    {Step::BALL_LOADING, 850}, 
    {Step::BACKWARD, 0.24, 1500, 0, 20, IntakeTurnOn::INTAKE},
    {Step::TONGUE_PNEUMATICS, 0, 0, false, IntakeTurnOn::INTAKE},
    {Step::DESCORE, 0, 0, true},
    {Step::TURN_RIGHT, 95}, 
    {Step::STRAIGHT, 0.45, 1500, 0, 30, IntakeTurnOn::INTAKE},
    {Step::TURN_RIGHT, 80}, 
    // {Step::TURN_LEFT, 90},
    {Step::STRAIGHT, 2.0, 3000, 0, 60, IntakeTurnOn::INTAKE},
    {Step::TURN_LEFT, 88},
    {Step::BACKWARD, 0.33, 1500, 0, 20, IntakeTurnOn::INTAKE},
    // {Step::FIND_WALL},
    {Step::TURN_RIGHT, 93},
    {Step::VISION_FIX, 30000, 0.1, 0, 3.83, IntakeTurnOn::INTAKE, 0}, 
    {Step::HIGH_GOAL_FIX, 90, 500}, 
    {Step::NO_BACKTRACKSCORING, 1500}, 
    {Step::TONGUE_PNEUMATICS, 0, 0, true, IntakeTurnOn::INTAKE},
    {Step::STRAIGHT, 0.28, 3000, 0, 40, IntakeTurnOn::INTAKE}, 
    {Step::STRAIGHT, 0.46, 3000, 0, 40, IntakeTurnOn::INTAKE}, 
    {Step::BALL_LOADING, 800}, 
    {Step::VISION_FIX, 30000, 0.7, 0, 3.83, IntakeTurnOn::INTAKE, 0.2}, 
    {Step::HIGH_GOAL_FIX, 90, 500}, 
    {Step::NO_BACKTRACKSCORING, 700}, 
    {Step::TONGUE_PNEUMATICS, 0, 0, false, IntakeTurnOn::INTAKE},
    {Step::STRAIGHT, 0.45, 3000, 0, 50, IntakeTurnOn::NOT_INTAKE}, 
    {Step::TURN_LEFT, 90}, 
    {Step::STRAIGHT, 0.40, 3000, 0, 20, IntakeTurnOn::INTAKE}, 
    {Step::BACKWARD, 0.04, 3000, 0, 100, IntakeTurnOn::INTAKE}, 
    // {Step::STRAIGHT, 0.04, 3000, true, 100},
    {Step::BACKWARD, 0.9, 3000, 0, 50, IntakeTurnOn::INTAKE}, 
    {Step::TURN_LEFT, 90}, 
    {Step::STRAIGHT, 1.75, 3000, 0, 60, IntakeTurnOn::INTAKE}, 
    {Step::TURN_RIGHT, 45}, 
    // {Step::VISION_FIX, 500}, 
    {Step::VISION_FIX, 30000, 0.3, 0, 7, IntakeTurnOn::NOT_INTAKE, 0}, 
    {Step::STRAIGHT, 0.05, 3000, 0, 100, IntakeTurnOn::NOT_INTAKE}, 
    {Step::MIDDLE_GOAL, 2500}, 
    {Step::STRAIGHT, 0.40, 3000, 0, 50, IntakeTurnOn::NOT_INTAKE}, 
    {Step::TURN_LEFT, 45},
    {Step::STRAIGHT, 1.1, 3000, 0, 50, IntakeTurnOn::NOT_INTAKE}, 
    // {Step::BACKWARD, 0.1, 3000, 0, 60, IntakeTurnOn::INTAKE}, 
    {Step::TURN_LEFT, 70}, 
    {Step::STRAIGHT, 0.15, 3000, 0, 10, IntakeTurnOn::NOT_INTAKE}, 
    {Step::TONGUE_PNEUMATICS, 0, 0, true, IntakeTurnOn::INTAKE},
    {Step::PARKING}, 
};


static vector<Step> competition_auton_1 = {
    {Step::STRAIGHT, 1.01, 2000, true, 100, IntakeTurnOn::INTAKE}, 
    {Step::BACKWARD, 0.24, 2000, true, 100, IntakeTurnOn::INTAKE}, 
    {Step::TURN_LEFT, 115},
    {Step::VISION_FIX, 700}, 
    {Step::BACKWARD, 0.35, 2000, false, 100, IntakeTurnOn::NOT_INTAKE}, 
    {Step::MIDDLE_GOAL, 1500},
    {Step::STRAIGHT, 1.0, 2000, false, 100, IntakeTurnOn::NOT_INTAKE},  
    {Step::TURN_RIGHT, 45}, 
    {Step::STRAIGHT, 0.22, 2000, true, 100, IntakeTurnOn::INTAKE}, 
    {Step::TURN_LEFT, 90}, 
    {Step::TONGUE_PNEUMATICS, 0, 0, true}, 
    {Step::STRAIGHT, 0.365, 2000, true, 100, IntakeTurnOn::INTAKE}, 
    {Step::BALL_LOADING, 1500}, 
    {Step::BACKWARD, 0.3, 2000, true, 100, IntakeTurnOn::INTAKE}, 
    {Step::VISION_FIX, 500},
    {Step::BACKWARD, 0.5, 2000, true, 100, IntakeTurnOn::INTAKE}, 
    {Step::NO_BACKTRACKSCORING, 1000}, 
    {Step::STRAIGHT, 0.3, 2000, false, 100, IntakeTurnOn::NOT_INTAKE}, 
    {Step::TURN_RIGHT, 45},
    {Step::BACKWARD, 0.45, 2000, false, 100, IntakeTurnOn::NOT_INTAKE}, 
    {Step::TURN_LEFT, 47},
    {Step::BACKWARD, 1.0, 2000, false, 100, IntakeTurnOn::NOT_INTAKE}, 
};

static vector<Step> competition_auton_2 = {
    {Step::STRAIGHT, 1.04, 3000, false, 60, IntakeTurnOn::NOT_INTAKE},
    {Step::TURN_LEFT, 90}, 
    {Step::TONGUE_PNEUMATICS, 0, 0, true, IntakeTurnOn::INTAKE},
    {Step::STRAIGHT, 0.24, 1500, true, 25, IntakeTurnOn::INTAKE},
    {Step::BALL_LOADING, 1000}, 
    {Step::BACKWARD, 0.22, 2000, true, 50, IntakeTurnOn::NOT_INTAKE}, 
    {Step::TONGUE_PNEUMATICS, 0, 0, false},
    {Step::TURN_RIGHT, 46},  
    {Step::VISION_FIX, 30000, 0.1, 0, 2.5, IntakeTurnOn::NOT_INTAKE, 0.8},
    {Step::DRIVE_MOTOR, 200}, 
    {Step::MIDDLE_GOAL, 2000}, 
    {Step::STRAIGHT, 0.25, 2000, false, 60, IntakeTurnOn::INTAKE},
        {Step::TURN_RIGHT, 5}, 
    {Step::STRAIGHT, 1.0, 2000, false, 60, IntakeTurnOn::COLOR_SORT_ON},
    {Step::TURN_LEFT, 51}, 
    {Step::TONGUE_PNEUMATICS, 0, 0, true},
    {Step::STRAIGHT, 0.43, 1500, true, 40, IntakeTurnOn::INTAKE},
    {Step::BALL_LOADING, 800}, 
    {Step::VISION_FIX, 30000, 0.5, 0, 3.83, IntakeTurnOn::INTAKE, 0},
    {Step::HIGH_GOAL_FIX, -90, 700},
    {Step::NO_BACKTRACKSCORING, 700}, 
    {Step::STRAIGHT, 0.3, 2000, false, 50, IntakeTurnOn::NOT_INTAKE}, 
    {Step::TURN_RIGHT, 45},
    {Step::BACKWARD, 0.47, 2000, false, 50, IntakeTurnOn::NOT_INTAKE}, 
    {Step::TURN_LEFT, 57},
    {Step::DESCORE, 0, 0, false},
    {Step::TONGUE_PNEUMATICS, 0, 0, false},
    {Step::BACKWARD, 0.3, 2000, false, 40, IntakeTurnOn::NOT_INTAKE}, 

};

static vector<Step> competition_auton_3 = {
    {Step::STRAIGHT, 1.04, 3000, false, 70, IntakeTurnOn::NOT_INTAKE},
    {Step::TURN_LEFT, 90}, 
    {Step::TONGUE_PNEUMATICS, 0, 0, true, IntakeTurnOn::INTAKE},
    {Step::STRAIGHT, 0.3, 1500, true, 30, IntakeTurnOn::INTAKE},
    {Step::BALL_LOADING, 600}, 
    {Step::BACKWARD, 0.13, 2000, true, 50, IntakeTurnOn::NOT_INTAKE}, 
    {Step::TONGUE_PNEUMATICS, 0, 0, false},
    {Step::TURN_RIGHT, 45}, 
    {Step::LOW_GOAL, 100}, 
    // {Step::BACKWARD, 0.8, 2000, true, 50, IntakeTurnOn::INTAKE}, 
    {Step::VISION_FIX, 30000, 0.1, 0, 2.5, IntakeTurnOn::INTAKE, 0.8},
    {Step::STRAIGHT, 0.05, 3000, false, 60, IntakeTurnOn::NOT_INTAKE},
    // {Step::LOW_GOAL, 75}, 
    {Step::MIDDLE_GOAL, 1200}, 
    {Step::STRAIGHT, 0.2, 1500, true, 30, IntakeTurnOn::NOT_INTAKE},
    {Step::LOW_GOAL, 200}, 
    {Step::TURN_LEFT, 133},
    {Step::STRAIGHT, 0.93, 3000, true, 60, IntakeTurnOn::NOT_INTAKE},
    {Step::TURN_LEFT, 133}, 
    {Step::STRAIGHT, 0.19, 3000, true, 60, IntakeTurnOn::NOT_INTAKE},
    {Step::LOW_GOAL, 800}, 
    {Step::BACKWARD, 0.1, 2000, false, 50, IntakeTurnOn::NOT_INTAKE}, 
    {Step::TURN_RIGHT, 45},
    {Step::CLEAR_PARKING}, 
    {Step::TURN_LEFT, 90},
    {Step::STRAIGHT, 1.58, 3000, false, 80, IntakeTurnOn::NOT_INTAKE},
    {Step::TURN_LEFT, 90}, 
    {Step::TONGUE_PNEUMATICS, 0, 0, true, IntakeTurnOn::INTAKE},
    {Step::STRAIGHT, 0.45, 1500, 0 , 40, IntakeTurnOn::INTAKE},
    {Step::BALL_LOADING, 600},
    {Step::VISION_FIX, 30000, 0.5, 0, 3.83, IntakeTurnOn::INTAKE, 0},
    {Step::NO_BACKTRACKSCORING, 1500}, 
};

static vector<Step> competition_auton_4 = {
    {Step::STRAIGHT, 1.04, 3000, false, 70, IntakeTurnOn::NOT_INTAKE},
    {Step::TURN_LEFT, 90}, 
    {Step::TONGUE_PNEUMATICS, 0, 0, true, IntakeTurnOn::INTAKE},
    {Step::STRAIGHT, 0.3, 1500, true, 40, IntakeTurnOn::INTAKE},
    {Step::BALL_LOADING, 600}, 
    {Step::VISION_FIX, 30000, 0.5, 0, 3.83, IntakeTurnOn::INTAKE, 0.4},
        {Step::HIGH_GOAL_FIX, -90, 1000}, 
    {Step::NO_BACKTRACKSCORING, 650}, 
    {Step::STRAIGHT, 0.45, 3000, true, 70, IntakeTurnOn::COLOR_SORT_ON},
    {Step::STRAIGHT, 0.3, 3000, true, 70, IntakeTurnOn::INTAKE},
    {Step::BALL_LOADING, 1000}, 
    {Step::VISION_FIX, 30000, 0.1, 0, 2.5, IntakeTurnOn::INTAKE, 0.4},   
            {Step::HIGH_GOAL_FIX, -90, 1000}, 
        {Step::NO_BACKTRACKSCORING, 900},
    {Step::TONGUE_PNEUMATICS, 0, 0, false, IntakeTurnOn::INTAKE},
        {Step::STRAIGHT, 0.45, 2000, false, 50, IntakeTurnOn::NOT_INTAKE}, 
    {Step::TURN_RIGHT, 45},
    {Step::VISION_FIX, 30000, 0.3, 0, 3.83, IntakeTurnOn::INTAKE, 0.3},  
    {Step::MIDDLE_GOAL, 1000},
    {Step::STRAIGHT, 0.8, 3000, false, 70, IntakeTurnOn::NOT_INTAKE},
    {Step::TURN_LEFT, 50}, 
        {Step::DESCORE, 0, 0, false},
     {Step::BACKWARD, 0.4, 2000, true, 30, IntakeTurnOn::NOT_INTAKE}, 
};

static map<Key, Routine> routineId() {
    map<Key, Routine> my_routine;
    my_routine[{RoutineID::R0, RIGHT}] = buildRoutine(competition_auton_2);

    return my_routine;
}

static void runRoutine(const map<Key, Routine>& all, RoutineID id, Side s, AutoDrive& d) {
    Key k{id, s};
    auto it = all.find(k);
    if (it == all.end()) return;

    Odometry odom; 
    
    for (auto& step : it->second) {
        step(d, odom);
        wait(20, msec);
    }
}

#endif