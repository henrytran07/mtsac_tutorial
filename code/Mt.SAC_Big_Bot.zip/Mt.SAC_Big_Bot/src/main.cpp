#include "vex.h"
#include "driving.h"
#include "autonomous_driving.h"
#include "robot_config.h"
using namespace vex;

competition comp; 

int main() {
    preAuton(); 
    comp.autonomous(autonomous);
    comp.drivercontrol(driverControl);
                // autonomous(); 
    while(true) {
        wait(100, msec);
    }
}